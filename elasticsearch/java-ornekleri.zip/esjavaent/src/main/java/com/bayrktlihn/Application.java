package com.bayrktlihn;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryAction;
import org.elasticsearch.index.reindex.DeleteByQueryRequestBuilder;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

public class Application {

	public static void main(String[] args) throws UnknownHostException {
		Settings settings = Settings.builder().put("cluster.name", "elasticsearch").build();

		TransportClient client = new PreBuiltTransportClient(settings)
				.addTransportAddress(new TransportAddress(InetAddress.getByName("localhost"), 9300));

//		List<DiscoveryNode> listedNodes = client.listedNodes();
//		
//		for(DiscoveryNode node : listedNodes) {
//			System.out.println(node);
//		}
//		ekleme
//		Map<String, Object> json = new HashMap<String, Object>();
//		json.put("name", "Apple Macbook Air");
//		json.put("detail", "Intel Core i5, 16G ram, 128GB SSD");
//		json.put("price","5420");
//		json.put("provider", "Apple Turkiye");
//		
//		IndexResponse indexResponse = client.prepareIndex("product", "_doc", "3").setSource(json, XContentType.JSON).get();
//		System.out.println(indexResponse.getId());

//		getirme
//		GetResponse getResponse = client.prepareGet("product", "_doc", "1").get();
//		Map<String, Object> source = getResponse.getSource();
//
//		String name = (String) source.get("name");
//		String provider = (String) source.get("provider");
//		String detail = (String) source.get("detail");
//		String price = (String) source.get("price");
//		
//		System.out.println("name= "+name);
//		System.out.println("provider= "+provider);
//		System.out.println("detail= "+detail);
//		System.out.println("price= "+price);

//		arama
//		SearchResponse searchResponse = client.prepareSearch("product").setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
//				.setQuery(QueryBuilders.matchQuery("detail", "Intel")).get();
//		
//		SearchHit[] hits = searchResponse.getHits().getHits();
//		
//		for(SearchHit hit : hits) {
//			Map<String, Object> sourceAsMap = hit.getSourceAsMap();
//			System.out.println(sourceAsMap);
//		}

//		silme
//		DeleteResponse deleteResponse = client.prepareDelete("product", "_doc", "1").get();
//		System.out.println(deleteResponse.getId());

		BulkByScrollResponse response = new DeleteByQueryRequestBuilder(client, DeleteByQueryAction.INSTANCE)
				.filter(QueryBuilders.matchQuery("detail", "Intel")).source("product").get();
		long deleted = response.getDeleted();
		
		System.out.println(deleted);
	}
}
