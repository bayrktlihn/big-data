package com.bayrktlihn;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class App {

	public static void main(String[] args) {
		MongoClient mc = MongoClients.create();
		MongoDatabase database = mc.getDatabase("test");
		MongoCollection<Document> collection = database.getCollection("user");

//		Document document = new Document().append("name", "Stephen Hawking").append("date", "1942")
//				.append("country", "England").append("dateOfDeath", "2018");
//
//		Document document2 = new Document().append("name", "Isaac Newton").append("date", "1643").append("country",
//				"England");

//		collection.insertOne(document);

//		List<Document> documents = new ArrayList<Document>();
//		documents.add(document);
//		documents.add(document2);
//
//		collection.insertMany(documents);

//		veri listeleme
//		FindIterable<Document> find = collection.find(eq("country", "England"));
//
//		for (Document document : find) {
//			System.out.println(document);
//		}
//		veri güncelleme
//		collection.updateOne(eq("date", "1942"), new Document("$set", new Document("date","1941")));

//		veri silme
//		collection.drop();
//		collection.deleteOne(eq("date","1941"));
//		veri tabanını silme
		database.drop();
	}

}
