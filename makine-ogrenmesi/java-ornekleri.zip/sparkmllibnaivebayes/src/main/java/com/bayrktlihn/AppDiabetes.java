package com.bayrktlihn;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.ml.classification.NaiveBayes;
import org.apache.spark.ml.classification.NaiveBayesModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class AppDiabetes {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");

		SparkSession sparkSession = SparkSession.builder().appName("spark-mllib-naive-bayes").master("local")
				.getOrCreate();

		String filePath = Paths.get("src/main/resources/diabetes.csv").toAbsolutePath().toString();

		Dataset<Row> loadData = sparkSession.read().format("csv").option("header", "true").option("inferSchema", "true")
				.load(filePath);

		String[] headers = { "Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI",
				"DiabetesPedigreeFunction", "Age", "Outcome" };
		
		List<String> headersResult = new ArrayList<String>();
		
		
		
		for(String header : headers) {
			
			String newHeader = header.equals("Outcome") ? "label" : header.toLowerCase()+"_cat";
			
			headersResult.add(newHeader);
			
			StringIndexer indexHeader = new StringIndexer().setInputCol(header).setOutputCol(newHeader);
			loadData = indexHeader.fit(loadData).transform(loadData);
		}
		
		String[] colList = headersResult.toArray(new String[headersResult.size()]);
		VectorAssembler vectorAssembler = new VectorAssembler().setInputCols(colList).setOutputCol("features");
	
		Dataset<Row> transformData = vectorAssembler.transform(loadData);
	
		Dataset<Row> finalData = transformData.select("label","features");
	
		Dataset<Row>[] datasets = finalData.randomSplit(new double[] {0.65,0.35});
		Dataset<Row> trainData = datasets[0];
		Dataset<Row> testData = datasets[1];
		
		NaiveBayes nb = new NaiveBayes();
		nb.setSmoothing(1);
		NaiveBayesModel model = nb.fit(trainData);
		
		Dataset<Row> predictions = model.transform(testData);
		
		MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator().setLabelCol("label").setPredictionCol("prediction").setMetricName("accuracy");
		
		double evaluate = evaluator.evaluate(predictions);
		
		System.out.println("Accuracy "+evaluate);
	}
}
