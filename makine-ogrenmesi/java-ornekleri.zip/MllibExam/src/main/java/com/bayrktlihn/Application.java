package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.LinearRegressionTrainingSummary;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class Application {
	public static void main(String[] args) {

		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");

		SparkSession sparkSession = SparkSession.builder().appName("spark-mllib").master("local").getOrCreate();

		String mySatisPath = Paths.get("src/main/resources/satis.csv").toAbsolutePath().toString();
		String myTestPath = Paths.get("src/main/resources/test.csv").toAbsolutePath().toString();

		Dataset<Row> rawData = sparkSession.read().format("csv").option("header", "true").option("inferSchema", "true")
				.load(mySatisPath);
		
		Dataset<Row> newData = sparkSession.read().format("csv").option("header", "true").option("inferSchema", "true").load(myTestPath);
		
		VectorAssembler featuresVector = new VectorAssembler().setInputCols(new String[] { "Ay" })
				.setOutputCol("features");

		Dataset<Row> transform = featuresVector.transform(rawData);
		
		Dataset<Row> transformNewData = featuresVector.transform(newData);
		

		Dataset<Row> finalData = transform.select("features", "Satis");

		Dataset<Row>[] datasets = finalData.randomSplit(new double[] { 0.7, 0.3 });

		Dataset<Row> trainData = datasets[0];
		Dataset<Row> testData = datasets[1];

		LinearRegression lr = new LinearRegression();
		lr.setLabelCol("Satis");

		LinearRegressionModel model = lr.fit(trainData);
		
		LinearRegressionTrainingSummary summary = model.summary();
		
		System.out.println(summary.r2());
		
//		Dataset<Row> transformTest = model.transform(testData);
//		Dataset<Row> transformTest = model.transform(transformNewData);
//
//		transformTest.show();

	}
}
