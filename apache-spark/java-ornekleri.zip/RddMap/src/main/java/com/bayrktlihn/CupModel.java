package com.bayrktlihn;

import lombok.AllArgsConstructor;

import lombok.Setter;
import lombok.ToString;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CupModel {
	private String yil;
	private String evsahibi;
	private String birinci;
	private String ikinci;
	private String ucuncu;
	private String dorduncu;
	private int toplamgol;
	private int toplamulke;
	private int toplammac;
	private int toplamkatilimci;
}
