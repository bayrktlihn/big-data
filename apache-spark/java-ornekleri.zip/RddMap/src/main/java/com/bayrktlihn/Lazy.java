package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

public class Lazy {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		JavaRDD<CupModel> cupModelRdd = textFileRdd.map(new Function<String, CupModel>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -5759131304604639393L;

			@Override
			public CupModel call(String v1) throws Exception {
				String [] data = v1.split(",");
				String yil = data[0];
				String evsahibi = data[1];
				String birinci = data[2];
				String ikinci = data[3];
				String ucuncu = data[4];
				String dorduncu = data[5];
				int toplamgol = Integer.parseInt(data[6]);
				int toplamulke = Integer.parseInt(data[7]);
				int toplammac = Integer.parseInt(data[8]);
				
				System.out.println(v1);
				
				int toplamkatilimci = Integer.parseInt(data[9].replace(".", ""));
				return new CupModel(yil, evsahibi, birinci, ikinci, ucuncu, dorduncu, toplamgol, toplamulke, toplammac, toplamkatilimci);
			}
			
		});
		
		System.out.println(cupModelRdd.count());
		
		
		
		
		context.close();
	}
}
