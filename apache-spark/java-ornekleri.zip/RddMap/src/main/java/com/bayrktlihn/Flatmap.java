package com.bayrktlihn;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.VoidFunction;

public class Flatmap {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		JavaRDD<String> flatMap = textFileRdd.flatMap(new FlatMapFunction<String, String>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public Iterator<String> call(String t) throws Exception {
				return Arrays.asList(t.split(",")).iterator();
			}
			
		});
		
		flatMap.foreach(new VoidFunction<String>() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = 5524453192624477161L;

			@Override
			public void call(String t) throws Exception {
				System.out.println(t);
			}
		});
		
		
		context.close();
		
	}
}
