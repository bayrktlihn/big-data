package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class Distinct {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		JavaRDD<String> distinct = textFileRdd.distinct();
		
		System.out.println(distinct.count());
		System.out.println(textFileRdd.count());
		
		context.close();
	}
}
