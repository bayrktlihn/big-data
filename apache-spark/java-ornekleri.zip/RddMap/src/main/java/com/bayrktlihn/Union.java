package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class Union {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		String myFilePathTwo = Paths.get("src/main/resources/WorldCupPlayers.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		JavaRDD<String> textFileRdd2 = context.textFile(myFilePathTwo);
		
		JavaRDD<String> union = textFileRdd.union(textFileRdd2);
		
		union.foreach(x -> {
			System.out.println(x);
		});
		
		System.out.println(textFileRdd.count());
		System.out.println(textFileRdd2.count());
		System.out.println(union.count());
		
		context.close();
	}
}
