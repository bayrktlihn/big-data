package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;

public class Sample {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		JavaRDD<String> sample = textFileRdd.sample(false, 0.5);
		
		sample.foreach(new VoidFunction<String>() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = 1245645986440223911L;

			@Override
			public void call(String t) throws Exception {
				System.out.println(t);
			}
		});
		
		
		context.close();
	}
}
