package com.bayrktlihn.pairRdd;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;

import com.bayrktlihn.CupModel;

import scala.Tuple2;

public class App {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");
		
		JavaSparkContext context = new JavaSparkContext("local","Map Func");
		
		String myFilePath = Paths.get("src/main/resources/WorldCups.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFileRdd = context.textFile(myFilePath);
		
		
		JavaRDD<CupModel> cupModelRdd = textFileRdd.map(new Function<String, CupModel>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = -5759131304604639393L;

			@Override
			public CupModel call(String v1) throws Exception {
				String [] data = v1.split(",");
				String yil = data[0];
				String evsahibi = data[1];
				String birinci = data[2];
				String ikinci = data[3];
				String ucuncu = data[4];
				String dorduncu = data[5];
				int toplamgol = Integer.parseInt(data[6]);
				int toplamulke = Integer.parseInt(data[7]);
				int toplammac = Integer.parseInt(data[8]);
				
				
				int toplamkatilimci = Integer.parseInt(data[9].replace(".", ""));
				return new CupModel(yil, evsahibi, birinci, ikinci, ucuncu, dorduncu, toplamgol, toplamulke, toplammac, toplamkatilimci);
			}
			
		});
		
		JavaPairRDD<String, Integer> mapToPair = cupModelRdd.mapToPair(new PairFunction<CupModel, String, Integer>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public Tuple2<String, Integer> call(CupModel t) throws Exception {
				return new Tuple2<String, Integer>(t.getBirinci(), t.getToplamkatilimci());
			}
		});
		
		mapToPair.foreach(new VoidFunction<Tuple2<String,Integer>>() {
			
			/**
			 * 
			 */
			private static final long serialVersionUID = -5653620929237069232L;

			@Override
			public void call(Tuple2<String, Integer> t) throws Exception {
				System.out.println(t._1+" "+t._2);
			}
		});
		
		JavaPairRDD<String, Iterable<Integer>> groupByKey = mapToPair.groupByKey();
		
		groupByKey.foreach(new VoidFunction<Tuple2<String,Iterable<Integer>>>() {
			
			/**
			 * 	
			 */
			private static final long serialVersionUID = 2601528237372341849L;

			@Override
			public void call(Tuple2<String, Iterable<Integer>> t) throws Exception {
				System.out.println(t._1+" "+t._2);
			}
		});
		
		
		
		context.close();
	}
}
