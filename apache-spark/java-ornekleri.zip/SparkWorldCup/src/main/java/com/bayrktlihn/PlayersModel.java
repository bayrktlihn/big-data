package com.bayrktlihn;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@AllArgsConstructor
@Getter
@Setter
@ToString
public class PlayersModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3788412252620859002L;
	
	private String roundID;
	private String matchID;
	private String team;
	private String coachTeam;
	private String lineup;
	private String shirtNumber;
	private String playerName;
	private String position;
	private String event;
	
	

}
