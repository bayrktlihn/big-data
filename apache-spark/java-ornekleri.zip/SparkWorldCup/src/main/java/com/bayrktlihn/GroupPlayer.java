package com.bayrktlihn;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@Setter
@ToString
public class GroupPlayer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -665985475180692697L;
	private String playerName;
	private int matchCount;


}
