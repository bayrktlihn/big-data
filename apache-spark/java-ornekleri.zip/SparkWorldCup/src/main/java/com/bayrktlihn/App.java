package com.bayrktlihn;

import java.nio.file.Paths;
import java.util.Iterator;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.SparkSession;
import org.bson.Document;
import org.spark_project.guava.collect.Iterators;

import com.mongodb.spark.MongoSpark;

import scala.Tuple2;

public class App {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "C:\\hadoop-common-2.2.0-bin-master");

		SparkSession session = SparkSession.builder().master("local").appName("MongoSpark")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.WorkCupCollection")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.WorkCupCollection").getOrCreate();

		JavaSparkContext context = new JavaSparkContext(session.sparkContext());

		String myFilePath = Paths.get("src/main/resources/WorldCupPlayers.csv").toAbsolutePath().toString();

		JavaRDD<String> textFileRdd = context.textFile(myFilePath);

		JavaRDD<PlayersModel> map = textFileRdd.map(new Function<String, PlayersModel>() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -7369504349964402306L;

			@Override
			public PlayersModel call(String v1) throws Exception {
				String[] data = v1.split(",", -1);
				String roundID = data[0];
				String matchID = data[1];
				String team = data[2];
				String coachTeam = data[3];
				String lineup = data[4];
				String shirtNumber = data[5];
				String playerName = data[6];
				String position = data[7];
				String event = data[8];

				return new PlayersModel(roundID, matchID, team, coachTeam, lineup, shirtNumber, playerName, position,
						event);
			}
		});

		JavaRDD<PlayersModel> filter2 = map.filter(new Function<PlayersModel, Boolean>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public Boolean call(PlayersModel v1) throws Exception {
				return v1.getTeam().equals("TUR");
			}
		});

		JavaRDD<PlayersModel> filter = map.filter(new Function<PlayersModel, Boolean>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 5174102040658499019L;

			@Override
			public Boolean call(PlayersModel v1) throws Exception {
				return v1.getPlayerName().equals("MESSI");
			}
		});

		System.out.println("Messi dünya kupalarında " + filter.count() + " kadar maç yaptı.");

		JavaPairRDD<String, String> mapToPair = filter2.mapToPair(new PairFunction<PlayersModel, String, String>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 4750860670345377219L;

			@Override
			public Tuple2<String, String> call(PlayersModel t) throws Exception {
				return new Tuple2<String, String>(t.getPlayerName(), t.getMatchID());
			}

		});

//		mapToPair.foreach(new VoidFunction<Tuple2<String,String>>() {
//			
//			@Override
//			public void call(Tuple2<String, String> t) throws Exception {
//				System.out.println(t._1 + " "+t._2);
//			}
//		});

		JavaPairRDD<String, Iterable<String>> groupByKey = mapToPair.groupByKey();

//		groupByKey.foreach(new VoidFunction<Tuple2<String, Iterable<String>>>() {
//
//			/**
//			 * 
//			 */
//			private static final long serialVersionUID = 7476031494144084965L;
//
//			@Override
//			public void call(Tuple2<String, Iterable<String>> t) throws Exception {
//				System.out.println(t._1 + " " + t._2);
//			}
//		});

		JavaRDD<GroupPlayer> map2 = groupByKey.map(new Function<Tuple2<String, Iterable<String>>, GroupPlayer>() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 2227593414517342482L;

			@Override
			public GroupPlayer call(Tuple2<String, Iterable<String>> v1) throws Exception {
				Iterator<String> iterator = v1._2.iterator();
				int size = Iterators.size(iterator);
				return new GroupPlayer(v1._1, size);
			}
		});

//		map2.foreach(new VoidFunction<GroupPlayer>() {
//
//			/**
//			 * 
//			 */
//			private static final long serialVersionUID = -427874698255100605L;
//
//			@Override
//			public void call(GroupPlayer t) throws Exception {
//				System.out.println(t.getPlayerName() + " " + t.getMatchCount());
//			}
//		});

		JavaRDD<Document> documentRdd = map2.map(new Function<GroupPlayer, Document>() {

			@Override
			public Document call(GroupPlayer v1) throws Exception {
				String json = String.format("{playerName : '%s', matchCount: %d}", v1.getPlayerName(),
						v1.getMatchCount());
				return Document.parse(json);
			}
		});
		
		MongoSpark.save(documentRdd);

		context.close();
	}
}
