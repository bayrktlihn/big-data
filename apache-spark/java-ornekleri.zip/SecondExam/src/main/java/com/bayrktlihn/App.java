package com.bayrktlihn;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class App {
	public static void main(String[] args) {
		JavaSparkContext context = new JavaSparkContext("local", "SecondExam");
		List<String> exam = Arrays.asList("Alber Einstein", "Isaac Newton", "Stephen Hawking");
		
		JavaRDD<String> firstRdd = context.parallelize(exam);
		
		System.out.println("Toplam satir "+firstRdd.count());
		
		context.close();
	}
}
