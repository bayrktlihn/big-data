package com.bayrktlihn;

import java.nio.file.Paths;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class App {
	public static void main(String[] args) {
		JavaSparkContext context = new JavaSparkContext("local", "First Exam");
		
		String myFilePath = Paths.get("src/main/resources/ilkdataset.csv").toAbsolutePath().toString();
		
		JavaRDD<String> textFile = context.textFile(myFilePath);
		
		System.out.println("ilk deger "+textFile.first());
		
		context.close();
	}
}
