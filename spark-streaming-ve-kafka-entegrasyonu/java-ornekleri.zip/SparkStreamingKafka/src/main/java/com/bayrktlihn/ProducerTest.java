package com.bayrktlihn;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.google.gson.Gson;

public class ProducerTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Gson gson = new Gson();
		String topicName = "search";

		Properties properties = new Properties();
		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.ByteArraySerializer");
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringSerializer");

		Producer<String, String> producer = new KafkaProducer<String, String>(properties);

		while (true) {
			System.out.println("Ara: ");
			String product = sc.nextLine();
			SearchProductModel model = new SearchProductModel();
			model.setProduct(product);
			String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			model.setTime(time);
			String json = gson.toJson(model);
			System.out.println(json);
			ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>(topicName, json);
			producer.send(producerRecord);
			System.out.println("Kafkaya gonderildi");
		}

	}
}
